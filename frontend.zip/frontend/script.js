document.getElementById('form').addEventListener('submit', async function(event) {
    event.preventDefault();

    const number = document.getElementById('number').value;
    const text = document.getElementById('text').value;

    const responseContainer = document.getElementById('response-container');
    const responseElement = document.getElementById('response');
    const historyList = document.getElementById('history-list');
    responseElement.textContent = 'Procesando...';

    try {
        const response = await fetch('http://127.0.0.1:9208/process/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                number: parseInt(number),
                text: text,
            }),
        });

        const data = await response.json();

        if (data.response) {
            // Mostrar la respuesta en la interfaz
            responseElement.textContent = `Respuesta: ${data.response}`;

            // Agregar la respuesta al historial
            const listItem = document.createElement('li');
            listItem.textContent = `Número: ${number}, Texto: "${text}", Respuesta: ${data.response}`;
            historyList.appendChild(listItem);
        } else {
            responseElement.textContent = `Error: ${data.error}`;
        }

    } catch (error) {
        responseElement.textContent = 'Error al conectar con el servidor.';
    }
});
